pwd
